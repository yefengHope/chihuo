package com.tmy.repository;

import com.tmy.entry.Article;
import com.tmy.repository.base.BaseRepository;

public interface ArticleRepository extends BaseRepository<Article, Integer> {
 
}
