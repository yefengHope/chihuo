package com.tmy.repository;

import com.tmy.entry.Blog;
import com.tmy.repository.base.BaseRepository;

public interface BlogRepository extends BaseRepository<Blog, Integer> {

}
