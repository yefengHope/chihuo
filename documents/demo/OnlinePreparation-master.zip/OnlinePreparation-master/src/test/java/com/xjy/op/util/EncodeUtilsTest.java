package com.xjy.op.util;

import junit.framework.TestCase;

public class EncodeUtilsTest extends TestCase {
    public void testGeneratePassword() throws Exception {
        System.out.println(EncodeUtils.generatePassword("123456"));
    }

    public void testValidatePassword() throws Exception {

    }
}
